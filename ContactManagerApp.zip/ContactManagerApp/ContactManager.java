import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import java.util.InputMismatchException;

public class ContactManager {
    private static ArrayList<Contact> contactList = new ArrayList<>();
    private static final String FILE_NAME = "contacts.txt";

    public static void main(String[] args) {
        loadContactsFromFile();

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nContact Manager Menu:");
            System.out.println("1. Add a new contact");
            System.out.println("2. View contacts");
            System.out.println("3. Edit a contact");
            System.out.println("4. Delete a contact");
            System.out.println("5. Save and exit");

            try {
                System.out.print("Enter your choice (1-5): ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character

                switch (choice) {
                    case 1:
                        addContact(scanner);
                        break;
                    case 2:
                        viewContacts();
                        break;
                    case 3:
                        editContact(scanner);
                        break;
                    case 4:
                        deleteContact(scanner);
                        break;
                    case 5:
                        saveContactsToFile();
                        System.out.println("Contacts saved. Exiting program.");
                        scanner.close();
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 5.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // Consume the invalid input
            }
        }
    }

    private static void addContact(Scanner scanner) {
        System.out.print("Enter the name: ");
        String name = scanner.nextLine();

        System.out.print("Enter the phone number: ");
        String phoneNumber = scanner.nextLine();

        System.out.print("Enter the email address: ");
        String emailAddress = scanner.nextLine();

        Contact newContact = new Contact(name, phoneNumber, emailAddress);
        contactList.add(newContact);

        System.out.println("Contact added successfully.");
    }

    private static void viewContacts() {
        if (contactList.isEmpty()) {
            System.out.println("No contacts available.");
        } else {
            System.out.println("Contact List:");
            for (Contact contact : contactList) {
                System.out.println(contact);
            }
        }
    }

    private static void editContact(Scanner scanner) {
        System.out.print("Enter the name of the contact to edit: ");
        String nameToEdit = scanner.nextLine();

        for (Contact contact : contactList) {
            if (contact.getName().equalsIgnoreCase(nameToEdit)) {
                System.out.print("Enter the new phone number: ");
                String newPhoneNumber = scanner.nextLine();
                contactList.remove(contact);
                contactList.add(new Contact(contact.getName(), newPhoneNumber, contact.getEmailAddress()));
                System.out.println("Contact edited successfully.");
                return;
            }
        }

        System.out.println("Contact not found.");
    }

    private static void deleteContact(Scanner scanner) {
        System.out.print("Enter the name of the contact to delete: ");
        String nameToDelete = scanner.nextLine();

        for (Contact contact : contactList) {
            if (contact.getName().equalsIgnoreCase(nameToDelete)) {
                contactList.remove(contact);
                System.out.println("Contact deleted successfully.");
                return;
            }
        }

        System.out.println("Contact not found.");
    }

    private static void saveContactsToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(contactList);
        } catch (IOException e) {
            System.out.println("Error saving contacts to file: " + e.getMessage());
        }
    }

    private static void loadContactsFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            contactList = (ArrayList<Contact>) ois.readObject();
        } catch (FileNotFoundException e) {
            System.out.println("No existing contacts file found. Starting with an empty contact list.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading contacts from file: " + e.getMessage());
        }
    }
}




// javac -Xlint:unchecked ContactManager.java //